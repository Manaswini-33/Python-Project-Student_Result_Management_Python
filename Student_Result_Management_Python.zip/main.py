
# Student Result Management System (Python)
# Features: Add student, calculate result, display report

class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def total(self):
        return sum(self.marks)

    def percentage(self):
        return self.total() / len(self.marks)

def main():
    students = []
    n = int(input("Enter number of students: "))

    for _ in range(n):
        name = input("Enter student name: ")
        marks = list(map(int, input("Enter marks (space separated): ").split()))
        students.append(Student(name, marks))

    print("\n--- Student Report ---")
    for s in students:
        print(f"Name: {s.name}, Total: {s.total()}, Percentage: {s.percentage():.2f}%")

if __name__ == "__main__":
    main()
