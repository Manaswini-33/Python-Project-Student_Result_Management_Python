
# Student Result Management System (Python)

## Description
A console-based Python mini project to manage student results.

## Features
- Add student details
- Calculate total marks
- Calculate percentage

## How to Run
python main.py
